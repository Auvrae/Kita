# bulk-rename

Bulk Rename is exactly that. A program that renames multiple files at once using modifiers. This is my first full GUI rust project so I am sorry about the spehgetti code. All feedback is welcome! 
