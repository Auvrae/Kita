use std::thread::{JoinHandle, spawn, park_timeout};
use std::time::Duration;
use std::sync::Arc;

use super::bulk_enum::{ThreadFunction, HashType, ThreadState};
use super::bulk_gui::BulkGui;
use super::bulk_impl::rename_file;
use super::bulk_hash;

pub fn thread(gui: &mut BulkGui, func: ThreadFunction) -> JoinHandle<()> {
    let progress = Arc::clone(&gui.thread_storage.progress);
    let hashes = Arc::clone(&gui.thread_storage.hashes);
    let errors = Arc::clone(&gui.thread_storage.errors);
    let state = Arc::clone(&gui.thread_storage.state);

    spawn(move || {
        match func {
            ThreadFunction::Hash(algorithm, paths) => {
                let progress_slice: f32 = (1.0 / paths.len() as f32) * 100.0;

                // Update Internal State
                *state.lock().unwrap() = ThreadState::Saving;
                let mut internal_hashes: Vec<String> = vec![];
                // Commit Changes
                for path in &paths {
                    match algorithm {
                        HashType::MD5 => {
                            internal_hashes.push(bulk_hash::hash_file(path.to_owned(), &bulk_hash::HashType::MD5));
                            *progress.lock().unwrap() += progress_slice;
                        },
                        HashType::Sha1 => {
                            internal_hashes.push(bulk_hash::hash_file(path.to_owned(), &bulk_hash::HashType::Sha1));
                            *progress.lock().unwrap() += progress_slice;
                        },
                        HashType::Sha256 => {
                            internal_hashes.push(bulk_hash::hash_file(path.to_owned(), &bulk_hash::HashType::Sha256));
                            *progress.lock().unwrap() += progress_slice;
                        },
                        HashType::Sha512 => {
                            internal_hashes.push(bulk_hash::hash_file(path.to_owned(), &bulk_hash::HashType::Sha512));
                            *progress.lock().unwrap() += progress_slice;
                        }
                    }
                }
                *hashes.lock().unwrap() = internal_hashes;
                *state.lock().unwrap() = ThreadState::Completed;
            },
            ThreadFunction::SaveUndoRedo(edit) => {
                let progress_slice: f32 = (1.0 / edit.edits as f32) * 100.0;

                // Update Internal State
                *state.lock().unwrap() = ThreadState::Saving;

                // Commit Changes
                for item in &edit.items {
                    match rename_file(item.path_original.to_owned(), item.path_edited.to_owned()) {
                        Ok(_) => {
                            *progress.lock().unwrap() += progress_slice;
                        },
                        Err(error) => {
                            let mut errs = errors.lock().unwrap();
                            errs.push(error.to_string());
                        }
                    }
                    timeout(Duration::from_millis(1));
                }

                *state.lock().unwrap() = ThreadState::Completed;
            },
        }
    })
}

fn timeout(time: Duration) {
    park_timeout(time);
}