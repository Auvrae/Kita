
use std::fs;
use std::io::BufReader;
use std::io::Read;
use sha2::*;
use sha1::*;
use md5::*;
use rustc_serialize::hex::ToHex;


pub enum HashType {
    MD5,
    Sha1,
    Sha256,
    Sha512
}

pub fn hash_file(path: String, hash_mode: &HashType) -> String {
    let file = fs::File::open(path).unwrap();
    let mut reader = BufReader::new(file);
    let mut buffer = [0; 1024];
    match hash_mode {
        HashType::MD5 => {
            let mut hasher = Md5::new();
            loop {
                let count = reader.read(&mut buffer).unwrap();
                if count == 0 { break }
                hasher.update(&buffer[..count]);
            }

            return format!("{}", &hasher.finalize().as_slice().to_hex());
        },
        HashType::Sha1 => {
            let mut hasher = Sha1::new();
            loop {
                let count = reader.read(&mut buffer).unwrap();
                if count == 0 { break }
                hasher.update(&buffer[..count]);
            }
            return format!("{}", &hasher.finalize().as_slice().to_hex());
        },
        HashType::Sha256 => {
            let mut hasher = Sha256::new();
            loop {
                let count = reader.read(&mut buffer).unwrap();
                if count == 0 { break }
                hasher.update(&buffer[..count]);
            }
            return format!("{}", &hasher.finalize().as_slice().to_hex());
        },
        HashType::Sha512 => {
            let mut hasher = Sha512::new();
            loop {
                let count = reader.read(&mut buffer).unwrap();
                if count == 0 { break }
                hasher.update(&buffer[..count]);
            }
            return format!("{}", &hasher.finalize().as_slice().to_hex());
        }
    };
}