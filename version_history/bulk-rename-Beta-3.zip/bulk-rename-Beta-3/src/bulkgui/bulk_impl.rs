use super::bulk_gui::*;
use super::bulk_enum::*;
use super::bulk_threads::thread;

use std::fs;
use std::io;
use std::path::Path;
use std::sync::Arc;
use std::sync::Mutex;
use faccess;
use faccess::AccessMode;
use faccess::PathExt;


pub fn get_folder(path: String, ignore_hidden: bool) -> io::Result<Folder> {
    //Get Folder, catagorize files and folders and make lists, return Folder
    let dirres = fs::read_dir(&path)?;
    let iter = dirres.into_iter().enumerate();
    let mut list_of_files: Vec<FolderItem> = vec![];
    let mut list_of_dirs: Vec<FolderItem> = vec![];
    let mut list_of_all: Vec<FolderItem> = vec![];
    for (_index, res) in iter {
        let item: fs::DirEntry = res?;
        let metadata = item.metadata()?;
        let name = item.file_name().to_str().unwrap().to_string();
        //println!("{:?} - {:?}", metadata.permissions().readonly(), name);
        let fpath_name = format!("{}{}", &path, &name);
        let can_read: bool;
        let fpath = Path::new(&fpath_name);
        if fpath.access(AccessMode::READ).is_ok() {
            can_read = true;
        } else { can_read = false };
        if metadata.is_dir() {
            if ignore_hidden {
                if !name.starts_with(".") {
                    let i = FolderItem { 
                        is_dir: true, 
                        name: name, 
                        read_into: can_read,
                        read_only: metadata.permissions().readonly(),
                        full_path: fpath_name 
                    };
                    list_of_dirs.push(i.clone());
                    list_of_all.push(i);
                } 
            } else {
                let i = FolderItem { 
                    is_dir: true, 
                    name: name,
                    read_into: can_read,
                    read_only: metadata.permissions().readonly(),
                    full_path: fpath_name  
                };
                list_of_dirs.push(i.clone());
                list_of_all.push(i);
            }
        } else {
            if ignore_hidden {
                if !name.starts_with(".") {
                    let i = FolderItem { 
                        is_dir: false, 
                        name: name,
                        read_into: can_read,
                        read_only: metadata.permissions().readonly(),
                        full_path: fpath_name 
                    };
                    list_of_files.push(i.clone());
                    list_of_all.push(i)
                };
            } else {
                let i = FolderItem { 
                    is_dir: false, 
                    name: name, 
                    read_into: can_read,
                    read_only: metadata.permissions().readonly(),
                    full_path: fpath_name  
                };
                list_of_files.push(i.clone());
                list_of_all.push(i)
            }
        }
    }
    list_of_all.sort_by_key(|a| a.name.to_owned().to_lowercase());
    list_of_dirs.sort_by_key(|a| a.name.to_owned().to_lowercase());
    list_of_files.sort_by_key(|a| a.name.to_owned().to_lowercase());

    return Ok(Folder { 
        path_full: path, 
        list_files: list_of_files, 
        list_folders: list_of_dirs, 
        list_all_items: list_of_all 
    });
}

pub fn rename_file(original_path: String, renamed_path: String) -> Result<(), io::Error> {
    fs::rename(original_path, renamed_path)
}

impl Default for BulkGui {
    fn default() -> Self {
        Self {
            os_string: "",
            version: "0.10.2.2",
            program_name: "Bulk Rename",
            first_cycle: true,
            update_all: true,
            show_all_items: false,

            errors: vec![],
            edits_redo: vec![],
            edits_undo: vec![],

            dialog_open_save: false,
            dialog_save_enabled: true,
            dialog_open_saving: false,
            dialog_saving_enabled: true,
            dialog_saving_title: "Writing Changes...".to_string(),
            dialog_open_error: false,
            dialog_error_enabled: true,
            dialog_open_redo: false,
            dialog_redo_enabled: true,
            dialog_open_undo: false,
            dialog_undo_enabled: true,
            dialog_debug_open: false,
            dialog_open_info: false,
            dialog_open_egui_info: false,

            files_selected: vec![],
            modifications_total: 0,
            window_min_size: vec![1366.0, 768.0],
            window_size: egui::vec2(0.0, 0.0),
            default_path: "".to_string(),

            section_browser_enabled: true,
            section_files_enabled: true,
            section_options_enabled: true,
            section_options_save_enabled: true,
            section_files_hovered: false,

            browser_folder: Folder::default(),
            browser_list_folders: vec![],
            browser_path_current: "".to_string(),
            browser_path_last: "".to_string(),
            browser_path_line: "".to_string(),

            table_files: vec![],
            table_files_selected: vec![],
            table_files_selected_vec: vec![],
            table_files_renamed: vec![],
            table_files_item_clicked: false,
            table_files_last_selected: 0,
            table_files_selected_total: 0,

            section_browser_size_x: 0.00,
            section_browser_percentage_min: 15,
            section_browser_percentage_max: 50,
            section_browser_percentage_current: 15,
            section_browser_size_y: 0.00,

            section_files_size_x: 0.00,
            section_files_percentage_min: 15,
            section_files_percentage_max: 50,
            section_files_percentage_current: 50,
            section_files_size_y: 0.00,

            section_options_size_x: 0.00,
            section_options_percentage_min: 35,
            section_options_percentage_current: 35,
            section_options_size_y: 0.00,

            section_options_name_enabled: false,
            section_options_name_textbox_enabled: false,
            section_options_combobox_name: "Keep".to_string(),
            section_options_combobox_value: NamingMode::Keep,
            section_options_combobox_default_value: NamingMode::Keep,
            section_options_name_value: "".to_string(),

            section_options_case_enabled: false,
            section_options_case_widgets_enabled: false,
            section_options_case_combobox_name: "Same".to_string(),
            section_options_case_combobox_value: CaseMode::Same,
            section_options_case_combobox_default_value: CaseMode::Same,
            section_options_case_combobox_label: "".to_string(),
            section_options_case_from: 0,
            section_options_case_to: 0,

            section_options_replace_enabled: false,
            section_options_replace_match_with: "".to_string(),
            section_options_replace_replace_with: "".to_string(),
            section_options_replace_match_first: true,

            section_options_remove_enabled: false,
            section_options_remove_first: 0,
            section_options_remove_last: 0,
            section_options_remove_to: 0,
            section_options_remove_from: 0,

            section_options_add_enabled: false,
            section_options_add_prefix: "".to_string(),
            section_options_add_insert: "".to_string(),
            section_options_add_suffix: "".to_string(),
            section_options_add_at: 0,

            section_options_numbering_enabled: false,
            section_options_numbering_widgets_enabled: false,
            section_options_numbering_insert_enabled: false,
            section_options_numbering_combobox_name: "None".to_string(),
            section_options_numbering_combobox_value: NumberingMode::None,
            section_options_numbering_combobox_default_value: NumberingMode::None,
            section_options_numbering_combobox_label: "".to_string(),
            section_options_numbering_at: 0,
            section_options_numbering_start: 1,
            section_options_numbering_pad: 0,

            section_options_hashing_enabled: false,
            section_options_hashing_combobox_name: "None".to_string(),
            section_options_hashing_combobox_value: HashMode::None,
            section_options_hashing_combobox_default_value: HashMode::None,
            section_options_hashing_combobox_label: "".to_string(),
            section_options_hashing_algo_combobox_name: "MD5".to_string(),
            section_options_hashing_algo_combobox_value: HashType::MD5,
            section_options_hashing_algo_combobox_default_value: HashType::MD5,
            section_options_hashing_algo_combobox_label: "".to_string(),

            hashing_hashed: false,
            hashing_hashes: vec![],

            button_defaults_enabled: false,
            button_undo_enabled: true,
            button_redo_enabled: true,
            button_browser_up_enabled: false,
            button_browser_directory_enabled: true,

            checkbox_lock_section_resizing: false,
            double_click_deselect_enabled: true,

            thread_progress: 0.0,
            action_pending: false,
            thread_storage: ThreadStorage::default(),
            thread_handle: None,
            thread_type: None,
            window_error_index: 0,
            window_error_text_box: "".to_string()
        }
    }
}

impl Default for FolderItem{
    fn default() -> Self {
        Self { 
            is_dir: false,
            name: "Default".to_string(),
            read_into: false,
            read_only: true,
            full_path: "".to_string()
        }
    }
}

impl Default for Folder {
    fn default() -> Self {
        Self {
            path_full: "".to_string(),
            list_files: vec![],
            list_folders: vec![],
            list_all_items: vec![]
        }
    }
}

impl Default for ThreadStorage {
    fn default() -> Self {
        Self {
            progress: Arc::new(Mutex::new(0.0)),
            hashes: Arc::new(Mutex::new(vec![])),
            errors: Arc::new(Mutex::new(vec![])),
            state: Arc::new(Mutex::new(ThreadState::None))
        }
    }
}


impl BulkGui {

    pub fn save(&mut self) {
        self.dialog_saving_title = "Writing Changes...".to_string();
        // Make Edit Struct and fill it.
        let mut edits = Edit {
            tag: "".to_string(),
            items: vec![],
            edits: 0
        };
        for (index, name_renamed) in self.table_files_renamed.iter().enumerate() {
            if self.table_files_selected[index]{
                let name_original = self.table_files[index].to_owned();
                let file_path_renamed = format!("{}{}", self.browser_path_current, name_renamed);
                let file_path_original = format!("{}{}", self.browser_path_current, name_original);
                let item = EdittedItem {
                    name_original: name_original.to_owned(),
                    name_edited: name_renamed.to_owned(),
                    path_original: file_path_original.to_owned(),
                    path_edited: file_path_renamed.to_owned()
                };
                edits.items.push(item);
                edits.edits += 1;
            }
        }
        self.edits_undo.push(edits.to_owned());
        self.thread_type = Some(ThreadType::Save);
        self.thread_handle = Some(thread(self, ThreadFunction::SaveUndoRedo(edits)));
        self.action_pending = true;
    }

    pub fn undo(&mut self) {
        // Make Edit Struct and fill it.
        let mut edits = Edit {
            tag: "".to_string(),
            items: vec![],
            edits: 0
        };
        for (_index, edditeditem) in self.edits_undo.pop().unwrap().items.iter().enumerate() {
            let item = EdittedItem {
                name_original: edditeditem.name_edited.to_owned(),
                name_edited: edditeditem.name_original.to_owned(),
                path_original: edditeditem.path_edited.to_owned(),
                path_edited: edditeditem.path_original.to_owned()
            };
            edits.items.push(item);
            edits.edits += 1;
        }
        self.edits_redo.push(edits.to_owned());
        self.thread_type = Some(ThreadType::Undo);
        self.thread_handle = Some(thread(self, ThreadFunction::SaveUndoRedo(edits)));
        self.action_pending = true;
    }

    pub fn redo(&mut self) {
        // Make Edit Struct and fill it.
        let mut edits = Edit {
            tag: "".to_string(),
            items: vec![],
            edits: 0
        };
        for (_index, edditeditem) in self.edits_redo.pop().unwrap().items.iter().enumerate() {
            let item = EdittedItem {
                name_original: edditeditem.name_edited.to_owned(),
                name_edited: edditeditem.name_original.to_owned(),
                path_original: edditeditem.path_edited.to_owned(),
                path_edited: edditeditem.path_original.to_owned()
            };
            edits.items.push(item);
            edits.edits += 1;
        }

        self.edits_undo.push(edits.to_owned());
        self.thread_type = Some(ThreadType::Redo);
        self.thread_handle = Some(thread(self, ThreadFunction::SaveUndoRedo(edits)));
        self.action_pending = true;
    }

    pub fn hash(&mut self) {
        self.dialog_saving_title = "Hashing...".to_string();
        let mut paths: Vec<String> = vec![];
        for (index, name_renamed) in self.table_files_renamed.iter().enumerate() {
            if self.table_files_selected[index]{
                let name_original = self.table_files[index].to_owned();
                paths.push(format!("{}{}", self.browser_path_current, name_original));
            }
        }

        self.thread_type = Some(ThreadType::Hash);
        thread(self, ThreadFunction::Hash(self.section_options_hashing_algo_combobox_value, paths.to_owned()));
        self.action_pending = true;
    }
}