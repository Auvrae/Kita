use super::bulk_gui;

#[derive(PartialEq)]
pub enum NamingMode {
    Keep,
    Remove,
    Reverse
}

#[derive(PartialEq)]
pub enum NumberingMode {
    None,
    Prefix,
    Suffix,
    PrefixAndSuffix,
    Insert
}

#[derive(PartialEq)]
pub enum CaseMode {
    Same,
    Upper,
    Lower
}

#[derive(PartialEq)]
pub enum HashMode {
    None,
    Prefix,
    Suffix
}

#[derive(Clone, Copy)]
pub enum HashType {
    MD5,
    Sha1,
    Sha256,
    Sha512
}

#[derive(Clone, Copy)]
pub enum ThreadState {
    None,
    Saving,
    Completed
}

#[derive(Clone)]
pub enum ThreadFunction {
    Hash(HashType, Vec<String>),
    SaveUndoRedo(bulk_gui::Edit),
}
pub enum ThreadType {
    Save,
    Undo,
    Redo,
    Hash,
}