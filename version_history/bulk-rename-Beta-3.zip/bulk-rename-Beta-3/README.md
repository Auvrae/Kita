# bulk-rename

Bulk Rename is exactly that. A program that renames multiple files at once using modifiers. This is my first full GUI rust project so I am sorry about the spehgetti code. All feedback is welcome! 

> Text Editting Features:
  * Case; Upper / Lower
  * Regex Replace
  * Remove
  * Add; Prefix / Insert / Suffix
  * Numbering; Prefix / Insert / Suffix & Number Padding

> Upcoming Features:
  * Hashing & Tagging
  * Multithreading
  * Save Presets


> This software in very active development and will be rapidly changing as I learn more about rust.
